package in.ac.vnrvjiet.convergence.presentation.splash;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.FirebaseApp;

import in.ac.vnrvjiet.convergence.R;
import in.ac.vnrvjiet.convergence.data.local.PersistentDeviceStorage;
import in.ac.vnrvjiet.convergence.presentation.home.MainActivity;
import in.ac.vnrvjiet.convergence.presentation.signup.PhoneNumberVerification;
import in.ac.vnrvjiet.convergence.presentation.signup.SignUpActivity;
import in.ac.vnrvjiet.convergence.presentation.util.BaseActivity;

public class SplashActivity extends BaseActivity {
    PersistentDeviceStorage persistentDeviceStorage;

    private static final String TAG = "SplashActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "onCreate: ");
        FirebaseApp.initializeApp(getContext());
        setContentView(R.layout.activity_splash);
        persistentDeviceStorage = PersistentDeviceStorage.getInstance(getContext());
    }

    private void checkSignUp() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!"null".equalsIgnoreCase(persistentDeviceStorage.getEmail())) {
                    if ("null".equalsIgnoreCase(persistentDeviceStorage.getPhoneNumber())) {
                        gotoPhoneVerificationScreen();
                    } else {
                        gotoMainScreen();
                    }
                } else {
                    gotoSignUpScreen();
                }
            }
        }, 800);
    }

    private void gotoPhoneVerificationScreen() {
        Log.i(TAG, "gotoPhoneVerificationScreen: ");
        Intent phoneNumberVerificationIntent = new Intent(getContext(), PhoneNumberVerification.class);
        phoneNumberVerificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(phoneNumberVerificationIntent);
    }

    private void gotoMainScreen() {
        Log.i(TAG, "gotoMainScreen: ");
        Intent mainScreenIntent = new Intent(getContext(), MainActivity.class);
        mainScreenIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(mainScreenIntent);
    }

    private void gotoSignUpScreen() {
        Log.i(TAG, "gotoSignUpScreen: ");
        Intent signUpScreenIntent = new Intent(getContext(), SignUpActivity.class);
        signUpScreenIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(signUpScreenIntent);
    }

    public Context getContext() {
        return SplashActivity.this;
    }

    @Override
    protected void onResume() {
        Log.i(TAG, "onResume: ");
        super.onResume();
        checkSignUp();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }
}