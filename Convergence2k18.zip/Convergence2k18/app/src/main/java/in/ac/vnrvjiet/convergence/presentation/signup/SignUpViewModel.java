package in.ac.vnrvjiet.convergence.presentation.signup;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import in.ac.vnrvjiet.convergence.presentation.util.SingleLiveEvent;

/**
 * Created by pinna on 12/29/2017.
 */

public class SignUpViewModel extends AndroidViewModel {

    private SingleLiveEvent googleSignInClickEvent = new SingleLiveEvent();
    private SingleLiveEvent phoneNumberNextClickSignal = new SingleLiveEvent();

    public SingleLiveEvent getPhoneNumberNextClickSignal() {
        return phoneNumberNextClickSignal;
    }

    public SingleLiveEvent getGoogleSignInClickEvent() {
        return googleSignInClickEvent;
    }

    public SignUpViewModel(@NonNull Application application) {
        super(application);
    }

    public void phoneNumberNextButton() {
        phoneNumberNextClickSignal.call();
    }

    public void googleSignUpClick() {
        googleSignInClickEvent.call();
    }
}
