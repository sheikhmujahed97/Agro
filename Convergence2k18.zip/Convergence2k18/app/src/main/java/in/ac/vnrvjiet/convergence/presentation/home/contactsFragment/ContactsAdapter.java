package in.ac.vnrvjiet.convergence.presentation.home.contactsFragment;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.util.List;

import in.ac.vnrvjiet.convergence.BR;
import in.ac.vnrvjiet.convergence.R;
import in.ac.vnrvjiet.convergence.models.ContactsModel;
import in.ac.vnrvjiet.convergence.presentation.home.MainViewModel;

/**
 * Created by pinna on 12/30/2017.
 */

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ViewHolder> {

    private static final String TAG = "ContactsAdapter";

    List<ContactsModel> contactsModelList;

    private MainViewModel mainViewModel;

    public ContactsAdapter(List<ContactsModel> contactsModelList, MainViewModel mainViewModel) {
        this.mainViewModel = mainViewModel;
        this.contactsModelList = contactsModelList;
        Log.i(TAG, "ContactsAdapter: constructor");
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        viewHolder = new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.person_contact_card, parent, false));
        return (ViewHolder) viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.getViewDataBinding().setVariable(BR.contactsModelPOJO, contactsModelList.get(position));
        holder.getViewDataBinding().setVariable(BR.contactsMainViewModel, mainViewModel);
        holder.getViewDataBinding().executePendingBindings();
    }

    @Override
    public int getItemCount() {
        return (contactsModelList == null) ? 0 : contactsModelList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final ViewDataBinding viewDataBinding;

        ViewHolder(View itemView) {
            super(itemView);
            viewDataBinding = DataBindingUtil.bind(itemView);
        }

        public ViewDataBinding getViewDataBinding() {
            return viewDataBinding;
        }
    }
}
