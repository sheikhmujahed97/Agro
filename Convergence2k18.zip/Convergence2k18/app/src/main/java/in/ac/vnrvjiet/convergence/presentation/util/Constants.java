package in.ac.vnrvjiet.convergence.presentation.util;

/**
 * Created by pinna on 12/29/2017.
 */

public class Constants {
    public static final String EMAIL_ID = "emailId";
    public static final String PHONE_NUMBER = "phoneNumber";
    public static final String EVENT_NAME_LIST = "eventNameList";
    public static final String EVENT_PARTICIPATION_TIME_LIST = "eventParticipationTime";
    public static String NAME = "name";
    public static String PROFILE_PIC = "profilePic";
}
